1.1.2 / 2016-01-17
==================

  * perf: enable strict mode

1.1.1 / 2014-12-30
==================

  * Improve `browserify` support

1.1.0 / 2014-07-05
==================

  * Add `CONNECT` method
 
1.0.1 / 2014-06-02
==================

  * Fix module to work with harmony transform

1.0.0 / 2014-05-08
==================

  * Add `PURGE` method

0.1.0 / 2013-10-28
==================

  * Add `http.METHODS` support
